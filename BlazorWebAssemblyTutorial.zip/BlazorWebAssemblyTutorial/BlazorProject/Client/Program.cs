using BlazorProject.Client.Services;
using Microsoft.AspNetCore.Components.WebAssembly.Hosting;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;
using Syncfusion.Blazor;
using System;
using System.Collections.Generic;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;

namespace BlazorProject.Client
{
    public class Program
    {
        public static async Task Main(string[] args)
        {
            Syncfusion.Licensing.SyncfusionLicenseProvider.RegisterLicense("NDg2MTM0QDMxMzkyZTMyMmUzMGlCUXl3UklqUG5nclg3bzZCNjNHYkZuSytTNEZHWFhSMm13cXU0WmhwdkU9;NDg2MTM1QDMxMzkyZTMyMmUzMEVnMnFEVnZGdWdQYUJYdUd0alUzbGNLYURXNlZBUXdyVk45VXZYUnEwdG89;NDg2MTM2QDMxMzkyZTMyMmUzMEhyY2tDcnAyODVGeDFlYUZNMzZpSnJkVWF6VGE3VEt2cVdZVTRkaE1UL009;NDg2MTM3QDMxMzkyZTMyMmUzMEh6UjJ6aVdhNWxrVUh6NTViNGdTL3pyUWxPL0RjTXorN2NSZ2d1eWlpZlU9;NDg2MTM4QDMxMzkyZTMyMmUzMFZvNEhiamlHV3RBeXlNZ2I3MnNiZTcvNDFuTTROa0lWczNSa0hCVElzSlU9;NDg2MTM5QDMxMzkyZTMyMmUzMENjMzZRUzViRmFkVFQvaHZZR053NmZENElJWVJRM1NwRURVN2tMMEtLd0U9;NDg2MTQwQDMxMzkyZTMyMmUzMG5peW9NaXJTWDZmZDF2c1RrQmdlNGVNM0VrV1ozNmhMeTFXbUtwaThWLzg9;NDg2MTQxQDMxMzkyZTMyMmUzMFN0RTk0cWczcFVRMVJJYnc1Rm5WR1YzZnhhWEx6ZUE2Zy9jalE4NlJXOGM9;NDg2MTQyQDMxMzkyZTMyMmUzMEUzcStLRndBK1ZjR1YwaVBNSUsybWdNc3ROb0xYK05adDhGckJyc3NWOU09;NDg2MTQzQDMxMzkyZTMyMmUzMFBCdE0zbkZZc1l6ZnkxWldZY3VrcDJKR0R6WUxJQ0M0TGF6cGtJbm9TLzA9");
            var builder = WebAssemblyHostBuilder.CreateDefault(args);
            builder.RootComponents.Add<App>("#app");
            builder.Services.AddHttpClient<IEmployeeService, EmployeeService>(client =>
            {
                client.BaseAddress = new Uri(builder.HostEnvironment.BaseAddress);
            });
            builder.Services.AddHttpClient<IDepartmentService, DepartmentService>(client =>
            {
                client.BaseAddress = new Uri(builder.HostEnvironment.BaseAddress);
            });
            //builder.Services.AddScoped(sp => new HttpClient { BaseAddress = new Uri(builder.HostEnvironment.BaseAddress) });
            builder.Services.AddSyncfusionBlazor();
            builder.Services.AddScoped<EmployeeAdaptor>();
            await builder.Build().RunAsync();
        }
    }
}
